import "./home.css";
import banner from './banner.jpg'

function Home(){

    return(
        <p>Home Page</p>
    );
}

export default Home