function FavoritesPage(){
    return(
        <p>Favorites Page</p>
    );
}

export default FavoritesPage